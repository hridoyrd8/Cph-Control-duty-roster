Cph Control Duty Roster - GitHub Pages এ প্রকাশ করার ধাপ
=========================================================

1. github.com এ লগইন করে New repository বানান (যেমন নাম: duty-roster), Public রাখুন।
2. "uploading an existing file" লিংকে চাপুন এবং এই ফোল্ডারের সব ফাইল (index.html, manifest.json,
   sw.js, তিনটি icon png) টেনে এনে ফেলুন। Commit changes চাপুন।
   (ZIP নয়, ভেতরের ফাইলগুলো আলাদাভাবে আপলোড করতে হবে)
3. Repository এর Settings > Pages এ যান। Source: "Deploy from a branch",
   Branch: main, Folder: / (root) বেছে Save চাপুন।
4. এক-দুই মিনিট পর ঠিকানা আসবে: https://<আপনার-ইউজারনেম>.github.io/duty-roster/
5. Chrome এ ঠিকানাটি খুলুন। ঠিকানা বারের ডানে "Install" আইকন আসবে (অথবা মেনু > Cast, save, and share
   > Install page as app)। ফোনে মেনু > "Add to Home screen" / "Install app"।

আপডেট করতে হলে একই repository তে ফাইল বদলে commit করুন। sw.js এর CACHE নামের শেষের সংখ্যা (v1 -> v2) বাড়ালে
সবার ফোনে নতুন সংস্করণ দ্রুত আসে।
